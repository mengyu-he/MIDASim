## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  echo = TRUE,
  message = FALSE, 
  warning = FALSE,
  eval = FALSE)

## ----load package, echo=FALSE-------------------------------------------------
#  library(MIDAS)
#  library(MASS)
#  library(psych, quietly = TRUE)
#  library(scam, quietly = TRUE)
#  library(pracma, quietly = TRUE)
#  library(vegan, quietly = TRUE)

## -----------------------------------------------------------------------------
#  devtools::install_local("MIDAS_0.1.0.tar.gz", dependencies = TRUE)

## -----------------------------------------------------------------------------
#  install_github("mengyu-he/MIDAS")

## -----------------------------------------------------------------------------
#  browseVignettes("MIDAS")

## -----------------------------------------------------------------------------
#  vignette("MIDAS_vignette", package = "MIDAS")

## -----------------------------------------------------------------------------
#  data("count.ibd")

## -----------------------------------------------------------------------------
#  library(HMP2Data)
#  IBD16S()

## -----------------------------------------------------------------------------
#  data("count.ibd")

## ---- eval = FALSE------------------------------------------------------------
#  library(HMP2Data)
#  IBD16S()
#  
#  count.ibd <- t(IBD16S_mtx[, colSums(IBD16S_mtx)>3000] )
#  count.ibd <- count.ibd[, colSums(count.ibd>0)>1]
#  
#  dim(count.ibd)

## -----------------------------------------------------------------------------
#  count.ibd.setup <- Midas.setup(count.ibd, n.break.ties = 100, fit.beta = F)

## -----------------------------------------------------------------------------
#  count.ibd.modified <- Midas.modify(count.ibd.setup,
#                                     lib.size = NULL,
#                                     mean.rel.abund = NULL,
#                                     taxa.1.prop = NULL)

## -----------------------------------------------------------------------------
#  new.lib.size=sample(1000:10000, size=700, replace=T)
#  count.ibd.modified <- Midas.modify(count.ibd.setup,
#                                     lib.size = new.lib.size)

## -----------------------------------------------------------------------------
#  new.lib.size=sample(1000:10000, size=146, replace=T)
#  count.ibd.modified <- Midas.modify(count.ibd.setup,
#                                     lib.size = new.lib.size,
#                                     taxa.1.prop = 'same',
#                                     mean.rel.abund='same')

## -----------------------------------------------------------------------------
#  beta=0.1
#  new.mean.rel.abund <- count.ibd.setup$mean.rel.abund
#  new.mean.rel.abund[1:10]=exp(beta)*new.mean.rel.abund[1:10]
#  new.mean.rel.abund=new.mean.rel.abund/sum(new.mean.rel.abund)
#  

## -----------------------------------------------------------------------------
#  count.ibd.modified <- Midas.modify(count.ibd.setup,
#                                     mean.rel.abund=new.mean.rel.abund)

## -----------------------------------------------------------------------------
#  new.taxa.1.prop=count.ibd.setup$taxa.1.prop
#  new.taxa.1.prop[1:10]=pmin(exp(beta)*new.taxa.1.prop[1:10],1)
#  count.ibd.modified <- Midas.modify(count.ibd.setup,
#                                     taxa.1.prop=new.taxa.1.prop)

## -----------------------------------------------------------------------------
#  count.ibd.modified <- Midas.modify(count.ibd.setup,
#                                     mean.rel.abund = new.mean.rel.abund,
#                                     taxa.1.prop = "same")

## -----------------------------------------------------------------------------
#  count.ibd.modified <- Midas.modify(count.ibd.setup,
#                                     lib.size = new.lib.size,
#                                     mean.rel.abund  = new.mean.rel.abund)

## -----------------------------------------------------------------------------
#  count.ibd.modified <- Midas.modify(count.ibd.setup,
#                                     lib.size = new.lib.size,
#                                     mean.rel.abund  = new.mean.rel.abund,
#                                     taxa.1.prop = 'same'
#                                     )

## -----------------------------------------------------------------------------
#  simulated.data <- Midas.sim(count.ibd.modified)
#  summary(simulated.data)

